DK Global Tech - Time Tracker System

Setup Instructions:
1. This system is designed for multi-company use.
2. Default company: Precious Hands (red theme).
3. To switch to another company (e.g. Nila May), update COMPANY_NAME in config.js and replace logo.
4. Contact support: dkglobaltech@gmail.com

Security:
- License required to activate system.
- Contact DK Global Tech for payment and access.

Developed by: Doseyian (Kelvin Sekeyian)